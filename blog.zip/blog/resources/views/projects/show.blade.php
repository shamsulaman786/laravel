@extends('layouts.app')

@section('content')
	<div>
		<h1>{{ $project->title }}</h1>
	</div>		
	<div class="content">
		{{ $project->description }}
	</div>
	<div>
		<a href="/projects/{{ $project->id }}/edit">Edit</a>
	</div>
@if($project->tasks->count())
	<div class="shadow-lg p-3 mb-5 bg-white rounded border">
		@foreach($project->tasks as $task)
			<div>
				<form method="POST" action="/completed-tasks/{{$task->id}}">
					@if($task->completed)
						@method('DELETE')
					@endif
					@csrf
				  <div class="custom-control custom-checkbox">
				    <label class=" {{ $task -> completed?'is-complete' : '' }}" for="completed" >
				    <input type="checkbox" class=" " name="completed" onChange="this.form.submit()" {{ ($task -> completed)? 'checked' : ''}} id="customCheck1">
					{{ $task->description }}				    	
				    </label>
				  </div>	
				</form>
				
			</div>
		@endforeach
	</div>
@endif
							<!-- Add Task -->
	<div class="shadow-lg p-3 mb-5 bg-white rounded border">
		<div>
			<form method="POST" action="/projects/{{ $project->id }}/tasks">
				@csrf
				<div class="form-group">
					<input type="text" name="description" class="form-control {{ $errors->has('description')? 'border-danger':''}}" id="exampleFormControlInput1" placeholder="New Task">
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-outline-primary">Submit</button>
				</div>
			</form>
		</div>
		<div class="mt-sm bg-danger">
			<div class="container has-error ">
				<ul class="list-unstyled ">	
					@foreach($errors->all() as $error)
						<li >{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		</div>
	</div>
@endsection