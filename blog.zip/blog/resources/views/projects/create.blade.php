@extends('layouts.app')


@section('content')
<div class="container">
		<h1 class="title">Create Project</h1>

	<form method="post" action="/projects">
		{{ csrf_field() }}
		<div class="form-group">
			<input type="text" name="title" class="form-control {{ $errors->has('title')? 'border-danger':''}}" id="exampleFormControlInput1" placeholder="Project title">
		</div>

		<div class="form-group">
			<textarea name="description" class="form-control {{ $errors->has('description')? 'border-danger':''}}" id="exampleFormControlInput1" placeholder="Project description"></textarea>
		</div>
		<div class="form-group"> 
			<button type="submit" class="btn btn-primary mb-2">submit</button>
		</div>
	</form>
</div>

<div class=" bg-danger">
	<div class="container has-error ">
		<ul class="list-unstyled ">	
			@foreach($errors->all() as $error)
				<li >{{ $error }}</li>
			@endforeach
		</ul>
	</div>
</div>
@endsection
