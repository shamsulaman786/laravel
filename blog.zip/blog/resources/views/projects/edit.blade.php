@extends('layouts.app')

@section('content')
	<div class=" title text-primary">
		<h1 >Edit Project</h1>
	</div>
	<div class="form">
		<form method="post" action="/projects/{{ $project->id }}">
			<!-- {{ method_field('PATCH') }} -->
			@method('PATCH')
			<!-- {{ csrf_field() }} -->
			@csrf
			<label for="exampleFormControlSelect2">Project id:</label>
			<div class="form-group">
				<input type="text" class="form-control" id="exampleFormControlInput1" name="id" placeholder="Project id" value="{{ $project->id}}">
			</div>

			<label for="exampleFormControlSelect2">Project title</label>
			<div class="form-group">
				<input type="text" class="form-control" id="exampleFormControlInput1" name="title" placeholder="Project title" value="{{ $project->title}}">
			</div>

			<label for="exampleFormControlSelect2">Project description</label>
			<div class="form-group" >
				<input name="description" class="form-control" id="exampleFormControlInput1" type= "text" placeholder="Project description" value="{{ $project->description}}"></input>
			</div>

	<!-- 		<div>
				<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Project description" value="{{ $project->description}}"></textarea>
			</div> -->

			<div class="form-group">
				<button type="submit" class="btn btn-primary mb-2">update</button>
			</div>
		</form>

		<form method="post" action="/projects/{{ $project->id }}">
			@method('DELETE')
			@csrf
			<div class="form-group">
				<button type="submit" class="btn btn-danger mb-2">delete</button>
			</div>
		</form>
	</div>


@endsection