
@extends('layouts.app')

@section('content')
	<h1>projects</h1>
	<ul>

		@foreach($projects as $project) 
			<div class="title">
				<li> <a href="/projects/{{$project->id}}/">{{ $project->title }} </a></li>
			</div>
		@endforeach
		
	</ul>
@endsection