@extends('layouts.app')


@section('content')
    <ul>
     <p>Welcome to laravel</p>
     <a href="/projects">go to projects</a>   
<!--  -->

    </ul>
@endsection