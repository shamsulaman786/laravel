<?php $__env->startSection('content'); ?>
	<div>
		<h1><?php echo e($project->title); ?></h1>
	</div>		
	<div class="content">
		<?php echo e($project->description); ?>

	</div>
	<div>
		<a href="/projects/<?php echo e($project->id); ?>/edit">Edit</a>
	</div>
<?php if($project->tasks->count()): ?>
	<div class="shadow-lg p-3 mb-5 bg-white rounded border">
		<?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div>
				<form method="POST" action="/completed-tasks/<?php echo e($task->id); ?>">
					<?php if($task->completed): ?>
						<?php echo method_field('DELETE'); ?>
					<?php endif; ?>
					<?php echo csrf_field(); ?>
				  <div class="custom-control custom-checkbox">
				    <label class=" <?php echo e($task -> completed?'is-complete' : ''); ?>" for="completed" >
				    <input type="checkbox" class=" " name="completed" onChange="this.form.submit()" <?php echo e(($task -> completed)? 'checked' : ''); ?> id="customCheck1">
					<?php echo e($task->description); ?>				    	
				    </label>
				  </div>	
				</form>
				
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php endif; ?>
							<!-- Add Task -->
	<div class="shadow-lg p-3 mb-5 bg-white rounded border">
		<div>
			<form method="POST" action="/projects/<?php echo e($project->id); ?>/tasks">
				<?php echo csrf_field(); ?>
				<div class="form-group">
					<input type="text" name="description" class="form-control <?php echo e($errors->has('description')? 'border-danger':''); ?>" id="exampleFormControlInput1" placeholder="New Task">
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-outline-primary">Submit</button>
				</div>
			</form>
		</div>
		<div class="mt-sm bg-danger">
			<div class="container has-error ">
				<ul class="list-unstyled ">	
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li ><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/laravel/blog/resources/views/projects/show.blade.php */ ?>