<?php $__env->startSection('content'); ?>
<div class="container">
		<h1 class="title">Create Project</h1>

	<form method="post" action="/projects">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<input type="text" name="title" class="form-control <?php echo e($errors->has('title')? 'border-danger':''); ?>" id="exampleFormControlInput1" placeholder="Project title">
		</div>

		<div class="form-group">
			<textarea name="description" class="form-control <?php echo e($errors->has('description')? 'border-danger':''); ?>" id="exampleFormControlInput1" placeholder="Project description"></textarea>
		</div>
		<div class="form-group"> 
			<button type="submit" class="btn btn-primary mb-2">submit</button>
		</div>
	</form>
</div>

<div class=" bg-danger">
	<div class="container has-error ">
		<ul class="list-unstyled ">	
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li ><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/laravel/blog/resources/views/projects/create.blade.php */ ?>