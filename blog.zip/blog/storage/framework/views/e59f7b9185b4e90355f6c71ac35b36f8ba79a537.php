<?php echo e($slot); ?>


<?php /* /var/www/html/laravel/blog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php */ ?>