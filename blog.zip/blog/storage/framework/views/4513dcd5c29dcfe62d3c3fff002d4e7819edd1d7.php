<?php $__env->startSection('content'); ?>
	<div class=" title text-primary">
		<h1 >Edit Project</h1>
	</div>
	<div class="form">
		<form method="post" action="/projects/<?php echo e($project->id); ?>">
			<!-- <?php echo e(method_field('PATCH')); ?> -->
			<?php echo method_field('PATCH'); ?>
			<!-- <?php echo e(csrf_field()); ?> -->
			<?php echo csrf_field(); ?>
			<label for="exampleFormControlSelect2">Project id:</label>
			<div class="form-group">
				<input type="text" class="form-control" id="exampleFormControlInput1" name="id" placeholder="Project id" value="<?php echo e($project->id); ?>">
			</div>

			<label for="exampleFormControlSelect2">Project title</label>
			<div class="form-group">
				<input type="text" class="form-control" id="exampleFormControlInput1" name="title" placeholder="Project title" value="<?php echo e($project->title); ?>">
			</div>

			<label for="exampleFormControlSelect2">Project description</label>
			<div class="form-group" >
				<input name="description" class="form-control" id="exampleFormControlInput1" type= "text" placeholder="Project description" value="<?php echo e($project->description); ?>"></input>
			</div>

	<!-- 		<div>
				<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Project description" value="<?php echo e($project->description); ?>"></textarea>
			</div> -->

			<div class="form-group">
				<button type="submit" class="btn btn-primary mb-2">update</button>
			</div>
		</form>

		<form method="post" action="/projects/<?php echo e($project->id); ?>">
			<?php echo method_field('DELETE'); ?>
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<button type="submit" class="btn btn-danger mb-2">delete</button>
			</div>
		</form>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/laravel/blog/resources/views/projects/edit.blade.php */ ?>