<?php $__env->startSection('content'); ?>
    <ul>
     <p>Welcome to laravel</p>
     <a href="/projects">go to projects</a>   
<!--  -->

    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/html/laravel/blog/resources/views/welcome.blade.php */ ?>