<?php

namespace App;


class Foo 
{
    
}
